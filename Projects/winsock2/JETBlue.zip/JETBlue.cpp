#include <iostream>
#include <string.h>
#include <assert.h>
#include <esent.h>

#pragma comment( lib, "esent.lib" )

int wmain(int /*argc*/, wchar_t* /*argv*/[])
{
    JET_ERR err = ::JetInit(
        0                                           // 0 as ESE instance
    );
    if( JET_errSuccess != err )
        return err;

    JET_SESID sessionID = JET_sesidNil;
    err = ::JetBeginSession(
        0,                                          // 0 as ESE instance
        &sessionID,                                 // return value
        0,                                          // reserved
        0                                           // reserved
    );
    if( JET_errSuccess != err )
    {
        ::JetTerm( 0 );
        return err;
    }

    JET_DBID dbID = JET_dbidNil;
    err = ::JetCreateDatabase(
        sessionID,                                  // session id
        "test.db",                                  // data base file name
        0,                                          // reserved
        &dbID,                                      // return value
        0                                           // zero flag == just create
    );
    if( JET_errSuccess != err )
    {
        ::JetEndSession( sessionID, 0 );
        ::JetTerm( 0 );
        return err;
    }

    JET_COLUMNCREATE columnCreate[ 2 ]  = { 0 };

    columnCreate[ 0 ].cbStruct          = sizeof( JET_COLUMNCREATE );
    columnCreate[ 0 ].szColumnName      = "PK";
    columnCreate[ 0 ].coltyp            = JET_coltypLong;
    columnCreate[ 0 ].grbit             = JET_bitColumnAutoincrement;
    columnCreate[ 0 ].err               = JET_errSuccess;

    columnCreate[ 1 ].cbStruct          = sizeof( JET_COLUMNCREATE );
    columnCreate[ 1 ].szColumnName      = "Value";
    columnCreate[ 1 ].coltyp            = JET_coltypLongText;
    columnCreate[ 1 ].cbMax             = 1024;
    columnCreate[ 1 ].grbit             = JET_bitColumnTagged;
    columnCreate[ 1 ].cp                = 1200;
    columnCreate[ 1 ].err               = JET_errSuccess;

    JET_INDEXCREATE indexCreate[ 2 ]    = { 0 };
    indexCreate[ 0 ].cbStruct           = sizeof( JET_INDEXCREATE );
    indexCreate[ 0 ].szIndexName        = "PK_index";
    indexCreate[ 0 ].szKey              = "+PK\0";
    indexCreate[ 0 ].cbKey              =
        static_cast< unsigned long >( ::strlen( indexCreate[ 0 ].szKey ) + 2 );
    indexCreate[ 0 ].grbit              = JET_bitIndexPrimary;
    indexCreate[ 0 ].err                = JET_errSuccess;

    indexCreate[ 1 ].cbStruct           = sizeof( JET_INDEXCREATE );
    indexCreate[ 1 ].szIndexName        = "Value_index";
    indexCreate[ 1 ].szKey              = "+Value\0";
    indexCreate[ 1 ].cbKey              =
        static_cast< unsigned long >( ::strlen( indexCreate[ 1 ].szKey ) + 2 );
    indexCreate[ 1 ].grbit              = JET_bitIndexUnique;
    indexCreate[ 1 ].err                = JET_errSuccess;

    JET_TABLECREATE tableCreate         = { 0 };
    tableCreate.cbStruct                = sizeof( tableCreate );
    tableCreate.szTableName             = "TestTable";
    tableCreate.rgcolumncreate          = columnCreate;
    tableCreate.cColumns                =
        sizeof( columnCreate ) / sizeof( columnCreate[ 0 ] );
    tableCreate.rgindexcreate           = indexCreate;
    tableCreate.cIndexes                =
        sizeof( indexCreate ) / sizeof( indexCreate[ 0 ] );
    tableCreate.tableid                 = JET_tableidNil;

    err = ::JetCreateTableColumnIndex( sessionID, dbID, &tableCreate );
    if( JET_errSuccess != err )
    {
        ::JetEndSession( sessionID, 0 );
        ::JetTerm( 0 );
        return err;
    }

    err = ::JetBeginTransaction( sessionID );
    if( JET_errSuccess != err )
    {
        ::JetCloseTable( sessionID, tableCreate.tableid );
        ::JetEndSession( sessionID, 0 );
        ::JetTerm( 0 );
        return err;
    }

    wchar_t* stringsToInsert [ ] = { L"FirstInsertedRow",
        L"SecondInsertedRow",
        L"ThirdInsertedRow",
        L"FourInsertedRow" };

    for( size_t n = 0;
        n != sizeof( stringsToInsert ) / sizeof( stringsToInsert[ 0 ] );
        ++ n )
    {
        err = ::JetPrepareUpdate( sessionID,
            tableCreate.tableid,
            JET_prepInsert );
        if( JET_errSuccess != err )
        {
            ::JetRollback( sessionID, 0 );
            ::JetCloseTable( sessionID, tableCreate.tableid );
            ::JetEndSession( sessionID, 0 );
            ::JetTerm( 0 );
            return err;
        }

        JET_SETCOLUMN setColumn = { 0 };
        setColumn.columnid                  = columnCreate[ 1 ].columnid;
        setColumn.pvData                    = stringsToInsert[ n ];
        setColumn.cbData                    = static_cast< unsigned long >
            ( ::wcslen( stringsToInsert[ n ] ) * sizeof( wchar_t ) );
        setColumn.err                       = JET_errSuccess;

        err = ::JetSetColumns( sessionID, tableCreate.tableid, &setColumn, 1 );
        if( JET_errSuccess != err )
        {
            ::JetRollback( sessionID, 0 );
            ::JetCloseTable( sessionID, tableCreate.tableid );
            ::JetEndSession( sessionID, 0 );
            ::JetTerm( 0 );
            return err;
        }

        err = ::JetUpdate( sessionID, tableCreate.tableid, 0, 0, 0 );
        if( JET_errSuccess != err )
        {
            ::JetRollback( sessionID, 0 );
            ::JetCloseTable( sessionID, tableCreate.tableid );
            ::JetEndSession( sessionID, 0 );
            ::JetTerm( 0 );
            return err;
        }
    }

    err = ::JetCommitTransaction( sessionID, 0 );
    if( JET_errSuccess != err )
    {
        ::JetRollback( sessionID, 0 );
        ::JetCloseTable( sessionID, tableCreate.tableid );
        ::JetEndSession( sessionID, 0 );
        ::JetTerm( 0 );
        return err;
    }

    err = ::JetSetCurrentIndex( sessionID, tableCreate.tableid, "Value_index" );
    if( JET_errSuccess != err )
    {
        ::JetCloseTable( sessionID, tableCreate.tableid );
        ::JetEndSession( sessionID, 0 );
        ::JetTerm( 0 );
        return err;
    }

    for( err = ::JetMove( sessionID, tableCreate.tableid, JET_MoveFirst, 0 );
        JET_errSuccess == err;
        err = ::JetMove( sessionID, tableCreate.tableid, JET_MoveNext, 0 ) )
    {
        unsigned long nPK = 0;
        unsigned long nReadBytes = 0;
        err = ::JetRetrieveColumn( sessionID,
            tableCreate.tableid,
            columnCreate[ 0 ].columnid,
            &nPK,
            sizeof( nPK ),
            &nReadBytes,
            0,
            0 );
        if( JET_errSuccess != err )
            break;
        assert( nReadBytes == sizeof( nPK ) );
        std::wcout << nPK;
        wchar_t buffer[ 1024 ] = { 0 };
        err = ::JetRetrieveColumn( sessionID,
            tableCreate.tableid,
            columnCreate[ 1 ].columnid,
            &buffer,
            sizeof( buffer ),
            &nReadBytes,
            0,
            0 );
        assert( nReadBytes < sizeof( buffer ) );
        std::wcout << L'\t' << buffer << std::endl;
    }

    if( JET_errNoCurrentRecord != err )
    {
        ::JetCloseTable( sessionID, tableCreate.tableid );
        ::JetEndSession( sessionID, 0 );
        ::JetTerm( 0 );
        return err;
    }

    std::wcout << std::endl;

    err = ::JetMove( sessionID, tableCreate.tableid, JET_MoveFirst, 0 );
    if( JET_errSuccess != err )
    {
        ::JetCloseTable( sessionID, tableCreate.tableid );
        ::JetEndSession( sessionID, 0 );
        ::JetTerm( 0 );
        return err;
    }

    wchar_t bufferSearchCriteria[ ] = L"Fo";
   err = ::JetMakeKey( sessionID,
        tableCreate.tableid,
        &bufferSearchCriteria,
        sizeof( bufferSearchCriteria ),
        JET_bitNewKey );
    if( JET_errSuccess != err )
    {
        ::JetCloseTable( sessionID, tableCreate.tableid );
        ::JetEndSession( sessionID, 0 );
        ::JetTerm( 0 );
        return err;
    }

    for( err = ::JetSeek( sessionID, tableCreate.tableid, JET_bitSeekGE );
        !( err < 0 );
        err = ::JetMove( sessionID, tableCreate.tableid, JET_MoveNext, 0 ) )
    {
        unsigned long nPK = 0;
        unsigned long nReadBytes = 0;
        err = ::JetRetrieveColumn( sessionID,
            tableCreate.tableid,
            columnCreate[ 0 ].columnid,
            &nPK,
            sizeof( nPK ),
            &nReadBytes,
            0,
            0 );
        if( JET_errSuccess != err )
            break;
        assert( nReadBytes == sizeof( nPK ) );
        std::wcout << nPK;
        wchar_t buffer[ 1024 ] = { 0 };
        err = ::JetRetrieveColumn( sessionID,
            tableCreate.tableid,
            columnCreate[ 1 ].columnid,
            &buffer,
            sizeof( buffer ),
            &nReadBytes,
            0,
            0 );
        assert( nReadBytes < sizeof( buffer ) );
        std::wcout << L'\t' << buffer << std::endl;
    }

    if( JET_errNoCurrentRecord != err )
    {
        ::JetCloseTable( sessionID, tableCreate.tableid );
        ::JetEndSession( sessionID, 0 );
        ::JetTerm( 0 );
        return err;
    }

    std::wcout << std::endl;

    err = ::JetMove( sessionID, tableCreate.tableid, JET_MoveFirst, 0 );
    if( JET_errSuccess != err )
    {
        ::JetCloseTable( sessionID, tableCreate.tableid );
        ::JetEndSession( sessionID, 0 );
        ::JetTerm( 0 );
        return err;
    }

    err = ::JetMakeKey( sessionID,
        tableCreate.tableid,
        &bufferSearchCriteria,
        sizeof( bufferSearchCriteria ),
        JET_bitNewKey | JET_bitPartialColumnStartLimit );
    if( JET_errSuccess != err )
    {
        ::JetCloseTable( sessionID, tableCreate.tableid );
        ::JetEndSession( sessionID, 0 );
        ::JetTerm( 0 );
        return err;
    }

    err = ::JetSeek( sessionID, tableCreate.tableid, JET_bitSeekGE );
    if( err < 0 )
    {
        ::JetCloseTable( sessionID, tableCreate.tableid );
        ::JetEndSession( sessionID, 0 );
        ::JetTerm( 0 );
        return err;
    }

    err = ::JetMakeKey( sessionID,
        tableCreate.tableid,
        &bufferSearchCriteria,
        sizeof( bufferSearchCriteria ),
        JET_bitNewKey | JET_bitPartialColumnEndLimit );
    if( JET_errSuccess != err )
    {
        ::JetCloseTable( sessionID, tableCreate.tableid );
        ::JetEndSession( sessionID, 0 );
        ::JetTerm( 0 );
        return err;
    }

    for( err = ::JetSetIndexRange( sessionID,
                                   tableCreate.tableid,
                                   JET_bitRangeInclusive |
                                   JET_bitRangeUpperLimit );
        !( err < 0 );
        ::JetMove( sessionID, tableCreate.tableid, JET_MoveNext, 0 ) )
    {
        unsigned long nPK = 0;
        unsigned long nReadBytes = 0;
        err = ::JetRetrieveColumn( sessionID,
            tableCreate.tableid,
            columnCreate[ 0 ].columnid,
            &nPK,
            sizeof( nPK ),
            &nReadBytes,
            0,
            0 );
        if( JET_errSuccess != err )
            break;
        assert( nReadBytes == sizeof( nPK ) );
        std::wcout << nPK;
        wchar_t buffer[ 1024 ] = { 0 };
        err = ::JetRetrieveColumn( sessionID,
            tableCreate.tableid,
            columnCreate[ 1 ].columnid,
            &buffer,
            sizeof( buffer ),
            &nReadBytes,
            0,
            0 );
        assert( nReadBytes < sizeof( buffer ) );
        std::wcout << L'\t' << buffer << std::endl;
    }

    ::JetCloseTable( sessionID, tableCreate.tableid );
    ::JetEndSession( sessionID, 0 );
    ::JetTerm( 0 );

    return 0;
}
