// sgen.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <fstream.h>
#include <iostream.h>
#include <stdlib.h>

/*
const maxTranlen=30;
const nbTransactions=500000;
*/
const maxTranlen=20;
const nbTransactions=100000;
const alphSize=100;

int rnd(int n) // nombre al�atoire entre 0 et N-1
{
	return rand()*(n-1)/RAND_MAX;
}

int main(int argc, char* argv[])
{

	srand(0);
	ofstream o("test.txt");
	o<<nbTransactions<<endl;
// Zipfian distribution
	int N;
	int *xTable;
	bool zipfian=true;
	if (zipfian)
	{
		float* sum=new float[alphSize];
		sum[0]=1;
		for(int k=1;k<alphSize;k++)
			sum[k]=sum[k-1]+1.0f/(k+1);
		int x=int(maxTranlen*nbTransactions/sum[alphSize-1]+1);
//		cout<<x<<endl;
//		cout<<sum[alphSize-1]<<endl;

		N=10*alphSize; //empirical value, x100 would be better, but 100 is already enough
		xTable=new int[N];
		k=0;
		for(int i=0;i<N;i++)
		{
			if (sum[k]*N/sum[alphSize-1]<i)
				k++;
			xTable[i]=k;
		};
		cout<<endl;
		delete[] sum;
	} else
	{ // uniform distribution
		N=alphSize;
		xTable=new int[N];
		for(int i=0;i<N;i++)
			xTable[i]=i;
	};
	int len,j;
	for(int i=0;i<nbTransactions;i++)
	{
		len=maxTranlen;
		o<<len;
		for (j=0;j<len;j++)
		{
			o<<" "<<xTable[rnd(N)];
		};
		o<<endl;
	};
	delete[] xTable;
	return 0;
}