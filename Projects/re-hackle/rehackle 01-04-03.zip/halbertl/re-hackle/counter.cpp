// counter.cpp: implementation of the counter class.
//
//////////////////////////////////////////////////////////////////////

#include "counter.h"
#include "sequence.h"
#include "transactions.h"
#include <stdlib.h>
#include <memory.h>

extern bool PRUNING;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

counter::counter(transactions* t, int msup): nbItems(0), minsup(msup)
{
	data.nbElements=0;
	data.dataSize=STARTSIZE;
	data.list= new element[STARTSIZE];
	nbTotal=0;
	tb=t;
	epoch=0;
}

counter::~counter()
{
	clear();
	delete[] data.list;
}

bool counter::empty()
{
	return nbItems==0;
}


void counter::del(elements* d)
{
	if (d==NULL)
		return;
	for (int i=0;i<d->nbElements;i++)
	{
		if (d->list[i].nbNodes>0 && d->list[i].nodes!=NULL)
		{
			delete[] d->list[i].nodes;
#ifndef SPIRIT
			if (d->list[i].representation!=NULL)
				delete[] d->list[i].representation;
#endif
			d->list[i].nbNodes=0;
		}
		del(d->list[i].siblings);
	};
	d->nbElements=0;
	if (d!=&data)
	{
		delete[] d->list;
		delete d;
	};

}

void counter::clear()
{
	del(&data);
	nbItems=0;
}

int counter::size()
{
	return nbItems;
}

element* counter::lookup(elements* data, int symbol)
{
	for(int i=0;i<data->nbElements;i++)
	{
		if (data->list[i].symbol==symbol)
			return &data->list[i];
	};
	return NULL;
}

element* counter::insert(int* seq, elements* data,int len)
// returns a reference to the last elements of the inserted 
// item 
{
	elements* tmp=data;
	element *e=lookup(data, *seq);
	bool created=false;
	if (e==NULL) //new symbol
	{
		if (data->nbElements==data->dataSize)
		{
			element* buff=data->list;
			data->dataSize*=2;
			data->list= new element[data->dataSize];
			if (data->list==NULL)
			{
				cout<<"Out of memory"<<endl;
				exit(-1);
			};
			memcpy(data->list,buff,sizeof(element)*data->nbElements);
			delete[] buff;
		};
		data->list[data->nbElements].symbol=*seq;
		data->list[data->nbElements].nbNodes=0;
		data->list[data->nbElements].sizeofNodes=0;
		data->list[data->nbElements].count=0;
		data->list[data->nbElements].siblings=NULL;
		data->list[data->nbElements].nodes=NULL;
#ifndef SPIRIT
		data->list[data->nbElements].representation=NULL;
#endif
		e=&data->list[data->nbElements];
		data->nbElements++;
		created=true;
	};
	if (len==1) //last character
	{
		if (created)
		{
			nbTotal++;
			nbItems++;
		}
		//		e->siblings=NULL;
		return e;
	} else
	{
		if (e->siblings==NULL)
		{
			e->siblings=new elements;
			e->siblings->nbElements=0;
			e->siblings->dataSize=2;
			e->siblings->list= new element[e->siblings->dataSize];
		};
		return insert(seq+1,e->siblings,len-1);
	}
}

#ifndef SPIRIT
void counter::add(sequence* seq,sequence* level2Representation, ExpressionTree* T)
{
	if (PRUNING)
	{
		int ssup=pruner.getSupport(seq);
		if (ssup>=minsup)
		{
			if (level2Representation!=NULL)
				T->items->add(level2Representation);
			else 
				T->items->add(seq);
		} else
			 if (ssup>-1)
				return;// dont count the same sequence twice
	}//if (PRUNING)
	element *e=insert(seq->seq,&this->data,seq->len);
	for(int i=0;i<e->nbNodes;i++)// cette verification est utile, ex pour 1*.1*
		if (e->nodes[i]==T)
			return; // never add a node twice for the same candidate;
	if (e->nbNodes==e->sizeofNodes)
	{
		ExpressionTree** buff=e->nodes;
		sequence** sbuff=e->representation;
		if (e->nbNodes==0)
				e->sizeofNodes=2;
			else
				e->sizeofNodes*=2;
		e->nodes=new ExpressionTreeP[e->sizeofNodes];
		e->representation=new sequenceP[e->sizeofNodes];

		if (e->nodes==NULL || e->representation==NULL)
		{
			cout<<"Out of memory"<<endl;
			exit(-1);
		}
		if (e->nbNodes!=0)
		{
			memcpy(e->nodes,buff,sizeof(ExpressionTree*)*e->nbNodes);
			memcpy(e->representation,sbuff,sizeof(sequence*)*e->nbNodes);
			free(buff);
			free(sbuff);
		};
	};
	e->nodes[e->nbNodes]=T;
	if (level2Representation==NULL)
	{
		e->representation[e->nbNodes]=NULL;
	} else
	{
		e->representation[e->nbNodes]=new sequence;
		copy(e->representation[e->nbNodes],level2Representation);
	};
	e->nbNodes++;
}	
#else
void counter::add(sequence* seq,itemset* origin/*,int end*/)
{
	element *e=insert(seq->seq,&this->data,seq->len);
	if (e->nbNodes==e->sizeofNodes)
	{
		itemset** buff=e->nodes;
		if (e->nbNodes==0)
				e->sizeofNodes=2;
			else
				e->sizeofNodes*=2;
		e->nodes=new itemsetP[e->sizeofNodes];

		if (e->nodes==NULL)
		{
			cout<<"Out of memory"<<endl;
			exit(-1);
		}
		if (e->nbNodes!=0)
		{
			memcpy(e->nodes,buff,sizeof(itemset*)*e->nbNodes);
			free(buff);
		};
	};
	e->nodes[e->nbNodes]=origin;
//	e->nodes[e->nbNodes]->end=end;
	e->nbNodes++;
}
#endif

void counter::count(int* transaction)
{
	element* e;
	elements* d;
	for(int i=0;i<transaction[0];i++)
	{
		d=&data;
		for(int j=0+i;j<transaction[0];j++)
		{
			e=lookup(d,transaction[j+1]);
			if (e==NULL)
				break;
			if (e->nbNodes>0)
			{
				if (e->epoch!=epoch)
				{
					e->count++;
					if (e->count==minsup)
					{
						opt1++;
						if (opt1==nbItems)
						{
							cout<<"Optimisation 1"<<endl;
						}
					}
					e->epoch=epoch;
				}; 
				if (e->siblings==NULL)
					break;
			};
			d=e->siblings;
		};//
	};
}


#ifndef SPIRIT
void counter::addItemset(itemset* i,ExpressionTree* T)
{
	if (i==NULL)
		return;
	for(int j=0;j<i->nbItems;j++)
		add(&i->data[j],NULL,T);
}
#endif

void counter::count(bool clear,itemset* i)
{
	opt1=0;
	if (nbItems==0)
		return;
	for (int j=0;j<tb->nbTransactions;j++)
	{
		epoch++;
		count(tb->tBase[j]);
		if (opt1==nbItems)
			break;
	}
	if (clear)
		i->clear();
	extract(i);
}

void counter::mine(sequence* seq,elements* d, itemset* it)
{
	if (d==NULL)
		return;
	int i,j;
	int len=seq->len++;
	for (i=0;i<d->nbElements;i++)
	{
		seq->len=len+1;
		seq->seq[len]=d->list[i].symbol;
		if (d->list[i].nbNodes>0) // seq contains a full sequence
		{
			pruner.setSupport(seq,d->list[i].count);
			if (d->list[i].count>=minsup)
			{
				for (j=0;j<d->list[i].nbNodes;j++)
				{
				#ifndef SPIRIT
					if (d->list[i].representation[j]==NULL)
					{
						d->list[i].nodes[j]->items->add(seq);
					} else
					{
						d->list[i].nodes[j]->items->add(d->list[i].representation[j]);
					};
				#else
				//	cout<<"Found:"<<d->list[i].nodes[j]<<":"<<*s<<endl;
					d->list[i].nodes[j]->add(seq,true);
				#endif
				};
				it->add(seq);
			};//if (d->list[i].count>=minsup)
		}
		mine(seq,d->list[i].siblings,it);
	}
}

void counter::stat()
{
	cout<<"Total candidates generated:"<<nbTotal<<endl;
	pruner.stat();
}


void counter::extract(itemset* it)
{
	sequence s;
	s.len=0;
	s.seq=new int[sequence::maxtranlen];
	s.count=0;
	s.len=0;
	mine (&s,&data,it);
}

ostream& operator<<(ostream& os, counter& c)
{

	return os;
}