// itemtree.cpp: implementation of the itemtree class.
//
//////////////////////////////////////////////////////////////////////

#include "itemtree.h"
#include "sequence.h"
#include <stdlib.h>
#include <memory.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

itemtree::itemtree(): nbItems(0)
{
	data.nbElements=0;
	data.dataSize=STARTSIZE;
	data.list= new ITelement[STARTSIZE];
}

itemtree::~itemtree()
{
	clear();
	delete[] data.list;
}

bool itemtree::empty()
{
	return nbItems==0;
}


void itemtree::del(ITelements* d)
{
	if (d==NULL)
		return;
	for (int i=0;i<d->nbElements;i++)
	{
		del(d->list[i].siblings);
	};
	d->nbElements=0;
	if (d!=&data)
	{
		delete[] d->list;
		delete d;
	};

}

void itemtree::clear()
{
	del(&data);
	nbItems=0;
}

int itemtree::size()
{
	return nbItems;
}

ITelement* itemtree::lookup(ITelements* data, int symbol)
{
	for(int i=0;i<data->nbElements;i++)
	{
		if (data->list[i].symbol==symbol)
			return &data->list[i];
	};
	return NULL;
}

ITelement* itemtree::insert(int* seq, ITelements* data,int len, int frequency)
// returns a reference to the last elements of the inserted 
// item 
{
	ITelements* tmp=data;
	ITelement *e=lookup(data, *seq);
	bool created=false;
	if (e==NULL) //new symbol
	{
		if (data->nbElements==data->dataSize)
		{
			ITelement* buff=data->list;
			data->dataSize*=2;
			data->list= new ITelement[data->dataSize];
			if (data->list==NULL)
			{
				cout<<"Out of memory"<<endl;
				exit(-1);
			};
			memcpy(data->list,buff,sizeof(ITelement)*data->nbElements);
			delete[] buff;
		};
		data->list[data->nbElements].symbol=*seq;
		data->list[data->nbElements].count=-1;
		data->list[data->nbElements].siblings=NULL;
		e=&data->list[data->nbElements];
		data->nbElements++;
		created=true;
		nbItems++;
	};
	if (len==1) //last character
	{
		if (e->count==-1)
			e->count=frequency;
		return e;
	} else
	{
		if (e->siblings==NULL)
		{
			e->siblings=new ITelements;
			e->siblings->nbElements=0;
			e->siblings->dataSize=2;
			e->siblings->list= new ITelement[e->siblings->dataSize];
		};
		return insert(seq+1,e->siblings,len-1,frequency);
	}
}

void itemtree::add(sequence* seq)
{
	ITelement *e=insert(seq->seq,&this->data,seq->len);
}


int itemtree::checkandinsert(sequence* seq)
{
	ITelement *e=insert(seq->seq,&this->data,seq->len);
	return e->count;
}


void itemtree::addItemset(itemset* i)
{
	if (i==NULL)
		return;
	for(int j=0;j<i->size();j++)
		add(&i->data[j]);
}


void itemtree::mine(sequence* s,ITelements* d, bool list)
{
	if (d==NULL)
		return;
	int i;
	int len=s->len++;
	for (i=0;i<d->nbElements;i++)
	{
		s->len=len+1;
		s->seq[len]=d->list[i].symbol;
		if (d->list[i].count>-1) //
		{
			if (list)
				cout<<"Found:"<<*s<<":"<<d->list[i].count<<endl;
		//	it->add(s);
		}
		mine(s,d->list[i].siblings,list);
	}
}

void itemtree::extract()
{
	sequence s;
	s.len=0;
	s.seq=new int[sequence::maxtranlen];
	s.count=0;
	s.len=0;
	mine (&s,&data,true);
}

bool itemtree::in(sequence* seq)
{
	ITelements* es=&data;
	ITelement* e=&data.list[0];
	if (e==NULL)
		return false;
	int* s=seq->seq;
	for(int i=0; i<seq->len;i++)
	{
		e=lookup(es,s[i]);
		if (e==NULL)
			return false;
		es=e->siblings;
	}
	return (i==seq->len);
}

void itemtree::setfrequency(sequence* seq, int frequency)
{
	insert(seq->seq,&data,seq->len,frequency);
}