// ExtractionPhrase.cpp: implementation of the ExtractionPhrase class.
//
//////////////////////////////////////////////////////////////////////



#include "ExtractionPhrase.h"
#include "ExpressionTree.h"
#include "KleeneTree.h"
#include "IntelliNode.h"
#include "Pruner.h"
#include <memory.h>
#include <stdlib.h>

const MAXCAND=50; // IntelliNode can have several siblings as far as its ksith<MAXCAND
extern bool USEINTELLINODE; // imported from tree.cpp

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

static int n;

ExtractionPhrase::ExtractionPhrase(counter* c): nbNodes(0),dataSize(ESTARTSIZE)
{
	nodes=new ExpressionTreeP[ESTARTSIZE];
	candidates=c;
}

ExtractionPhrase::~ExtractionPhrase()
{
	delete[] nodes;
}

void ExtractionPhrase::updateNodes()
// called before reBuild
{
	KleeneTree* kt;
	for (int i=0;i<nbNodes;i++)
	{
		switch (nodes[i]->type)
		{
			case ' ':
			case '.':
			case 'I':
				if (nodes[i]->items->size()==0)
					{
						nodes[i]->state=Violated;
						nodes[i]->propagateViolation();
					} else
					{
						nodes[i]->state=Satisfied;
					};
					nodes[i]->explored=true;
					nodes[i]->ksiexp=nodes[i]->items->size();
					break;
			case '*':
				kt=(KleeneTree*)nodes[i];
				if (kt->size(kt->age)==0)
				{
					kt->explored=true;
					kt->ksiexp=kt->items->size();
				};
				break;
			default:
				cout<<"ExtractionPhrase::updateNodes->Error."<<endl;
		}; //switch
	}// for
}

ExtractionPhrase*  ExtractionPhrase::reBuild()
{
	ExpressionTreeP *oldPhrase=new ExpressionTreeP[nbNodes];
	memcpy(oldPhrase,nodes,sizeof(ExpressionTreeP)*nbNodes);
	n=nbNodes;
	nbNodes=0;
	for (pos=0;pos<n;pos++)
	{
		if (oldPhrase[pos]->explored && oldPhrase[pos]->parent!=NULL)
			addNode(oldPhrase[pos]->parent);
		if (!oldPhrase[pos]->explored && oldPhrase[pos]->type=='*')
			addSimpleNode(oldPhrase[pos]);
	}
	delete[] oldPhrase;
	return this;
}

void ExtractionPhrase::initPhrase(ExpressionTree* T)
{
	if (T->type==' ')
	{
		addSimpleNode(T);
	}else
	{
		ExpressionTree* tmp=T->siblings;
		while (tmp!=NULL)
		{
			initPhrase(tmp);
			tmp=tmp->next;
		};
	}//if (T->type=' ')
}

bool ExtractionPhrase::addSimpleNode(ExpressionTree* N)
{
	if (nbNodes==dataSize)
	{
	// increase the buffer
		ExpressionTree** buff=nodes;
		dataSize*=2;
		nodes=(ExpressionTree**)malloc(dataSize*sizeof(ExpressionTree*));
		if (nodes==NULL)
		{
			cout<<"Out of memory"<<endl;
			return false;
		}
		memcpy(nodes,buff,sizeof(ExpressionTree*)*nbNodes);
		free(buff);
	};
	nodes[nbNodes]=N;
	nbNodes++;
	return true;
}

void ExtractionPhrase::addNode(ExpressionTree* N)
{
	// le champs parent des fils des iNode n'a pas de sens. (certains fils ont deux peres!) 
	if (!N->ready() || N->violated())
		return; // this node shouldn't be added
	for (int i=0;i<nbNodes;i++)
		if (nodes[i]==N)
			return; // the node was already added
	switch (N->type)
	{
		case '.':
			{
			ExpressionTree* S=N->siblings;
			int nbSiblings=0;
			int nbItemsinSiblings=1;
			while (S!=NULL)
			{
				nbSiblings++;
				if (nbItemsinSiblings*S->items->size()>0)
					nbItemsinSiblings*=S->items->size(); //sinon overflow, car 64^6=0!!!
				S=S->next;			
			};
	//		if (nbSiblings>5 && nbItemsinSiblings/nbSiblings>5)
			if (USEINTELLINODE && MAXCAND<nbItemsinSiblings && nbSiblings>2 && nbItemsinSiblings/nbSiblings>3)
			{
				cout<<"Inserting IntelliNode"<<endl;
				//create IntelliNodes
				S=N->siblings;
				IntelliNode* previous=NULL;
				while (S!=NULL)
				{
					if (S->next==NULL)
						break;
					IntelliNode* iNode=new IntelliNode();
					if (previous!=NULL)
					{
						previous->next=iNode;
						iNode->prev=previous;
					} else
						N->siblings=iNode;
					iNode->parent=N;
					iNode->siblings=S;
					/*if (S->prev!=NULL && S->next!=NULL && S->type=='I')
						S->goLevel2();*/
					iNode->nbSiblings=1;
					iNode->K=S->items->length(); // la longueur de tous les 
					// items de S est identique
					iNode->ksith=S->items->size();
					do 
					{
						S=S->next;
						if (S!=NULL)
						{
							iNode->ksith*=S->items->size();
							iNode->nbSiblings++;
						}
					} while (S!=NULL && iNode->ksith<MAXCAND);
					previous=iNode;
					addSimpleNode(iNode);
				}; //while (S!=NULL)
			} else addSimpleNode(N);
			}; // case '.':
			break;
		case '|':
			{
				if (N->parent==NULL) // N is the root
				{
					ExpressionTree* tmp=N->siblings;
					while (tmp!=NULL)
					{
						N->items->addItemset(tmp->items,true);
						tmp=tmp->next;
					};
					return;
				}
				ExpressionTree* np=N;
				N->explored=true;
				while (np->parent!=NULL && np->parent->type=='|')
					np=np->parent;
				if (N->parent!=NULL)
				{
					ExpressionTree* tmp=N->siblings;
					while (tmp!=NULL)
					{
						np->items->addItemset(tmp->items,true);
						tmp=tmp->next;
					};
					if (np->parent!=NULL)
						addNode(np->parent);
				} else addNode(N);
			};
			break;
		default:
			addSimpleNode(N);
	}; // switch (N->parent->type)
}

counter* ExtractionPhrase::generateCandidates()
{
	candidates->clear();
	for (int i=0;i<nbNodes;i++)
	{
		nodes[i]->generateCandidates(candidates);
	};
	return candidates;
}