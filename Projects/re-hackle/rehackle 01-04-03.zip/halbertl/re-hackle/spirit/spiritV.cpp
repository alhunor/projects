// spiritV.cpp: implementation of the spiritV class.
//
//////////////////////////////////////////////////////////////////////

#include "spiritV.h"
#include <memory.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

stateList::~stateList()
{
	delete[] statesList[1];
	delete[] statesList[0];
}

void stateList::addState(int list, int state) // adds teh sate <state> in the list <list>
{	
	bool in=false;
	for (int i=0;i<statesinList[list];i++)
	{
		if (statesList[list][i]==state)
		{
			in=true;
			return;
		}
	};
	if (!in)
	{
		statesList[list][statesinList[list]]=state;
		statesinList[list]++;
	}
}

void stateList::clear(int list)
{
	statesinList[list]=0;
}


spiritV::spiritV(int nb, int** A, counter* C):candidates(C),nbStates(nb),automaton(A),generation(1)
{
	sList=new stateList(nbStates);
	seqStates[0]=new itemset[nbStates];
	seqStates[1]=new itemset[nbStates];
}

spiritV::~spiritV()
{
	delete[] seqStates[1];
	delete[] seqStates[0];
}

bool spiritV::generateCandidates()
{
	int i,j,k,l;
	bool generated=false;
	sequence seq;
	candidates->clear();
	seq.len=generation;
	if (generation==1)
	{
		seq.seq=new int;
		sList->clear(0);
		for (i=0;i<nbStates;i++)
		{
			int* &transitions=automaton[i*nbStates+nbStates-1]; // transition i->nbStates-1
			if (transitions!=NULL)
			{
				sList->addState(0,i); 
				for (j=1;j<=transitions[0];j++)
				{
					seq.seq[0]=transitions[j];
					generated=true;
					candidates->add(&seq,&seqStates[0][i]);
				}
			}
		}
		delete seq.seq;
	} else // generation>1
	{
		seq.seq=new int[generation];
		int oldidx=generation % 2;
 		sList->clear(1-oldidx);
		for(i=0;i<sList->statesinList[oldidx];i++)
		{
			int a=sList->statesList[oldidx][i]; // transition is of the form j->a
			if (a==0)
				solution.addItemset(&seqStates[oldidx][a],true);
//			cout<<"State:"<<a<<endl;
			for (j=0;j<nbStates;j++)
			{
				int* &transitions=automaton[j*nbStates+a];
				if (transitions!=NULL)
				{
					sList->addState(1-oldidx,j);
					seqStates[oldidx][a].initFind();
					for (k=0;k<seqStates[oldidx][a].size();k++)
					{
						sequence* seq2=seqStates[oldidx][a].currentItem();
						memcpy(seq.seq+1,seq2->seq,seq2->len*sizeof(int));
						seqStates[oldidx][a].findNext();
					//	seq.len=generation;
						for (l=1;l<=transitions[0];l++)
						{
							seq.seq[0]=transitions[l];
							//cout<<seq<<endl;
							candidates->add(&seq,&seqStates[1-oldidx][j]);
							generated=true;
						}; // transitions
					};// items in Fk(j);
				}
			}// search for j from j->a
		}// loop for a=f(i)
		delete[] seq.seq;
/*		for(i=0;i<sList->statesinList[oldidx];i++)
			seqStates[oldidx][sList->statesinList[i]].clear();
*/
	}
	generation++;
	return generated;
}

void spiritV::pruneCandidates()
{

}
