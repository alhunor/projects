// spiritV.h: interface for the spiritV class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _SPIRITL_H__
#define _SPIRITL_H__

#include "../counter.h"

class spiritL  
{
public:
	spiritL(int nbStates, int** A, counter* C);
	virtual ~spiritL();
	bool generateCandidates();
	void pruneCandidates();
	itemset* getSolution(); // Should be called after the extraction in order 
	//to reinforce the constraint 
	bool test(sequence* seq, int state, int k);
	// returns true if seq satisfies the constraint beginning from the state <state> and the index k
protected:
	bool overlappedAdd(int state, itemset* its, sequence* seq,sequence* seq2);
	void mineSolution(sequence* seq,ITelements* d,itemset* it);
	itemtree F;
	itemset* seqStates[2]; // seqsates[][a] contains the sequences leaving the node "a"
	counter* candidates;
	int nbStates;
	int** automaton;
	int generation;
};

#endif 
