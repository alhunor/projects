// spiritV.cpp: implementation of the spiritV class.
//
//////////////////////////////////////////////////////////////////////

#include "spiritL.h"
#include <memory.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

spiritL::spiritL(int nb, int** A, counter* C):candidates(C),nbStates(nb),automaton(A),generation(1)
{
	seqStates[0]=new itemset[nbStates];
	seqStates[1]=new itemset[nbStates];
}


spiritL::~spiritL()
{
	delete[] seqStates[1];
	delete[] seqStates[0];
}

bool spiritL::overlappedAdd(int state,itemset* its, sequence* seq,sequence* seq2)
// generation-1 telecoped concatenation of seq and seq2 is added to its
{
	bool overlapping=true;
    for (int i=1;i<generation-1;i++)
		if (seq->seq[i]!=seq2->seq[i-1])
		{
			overlapping=false;
			break;
		};
	if (overlapping)
	{
		sequence s;
		s.len=generation;
		s.seq=new int[generation];
		s.seq[0]=seq->seq[0];
		memcpy(s.seq+1,seq2->seq,(generation-1)*sizeof(int));
//		its->add(&s,false);
		candidates->add(&s,its/*,state*/);
//		cout<<"*";
		return true;
	};
  //  cout<<"+";
	return false;
}

bool spiritL::generateCandidates()
{
	int i,j,k,l,l2;
	bool generated=false;
	sequence seq;
	sequence *seq2,*seq3;
	candidates->clear();
	seq.len=generation;
	if (generation==1)
	{
		seq.seq=new int;
		for (j=0;j<nbStates;j++)
			for (i=0;i<nbStates;i++)
			{
				int* &transitions=automaton[i*nbStates+j]; //transition i->j
				if (transitions!=NULL)
				{
					for (k=1;k<=transitions[0];k++)
					{
						seq.seq[0]=transitions[k];
						generated=true;
						candidates->add(&seq,&seqStates[0][i]/*,i*/);
					}
				}
		}
		delete seq.seq;
	} else // generation>1
	{
		seq.seq=new int[generation];
		int oldidx=generation % 2;
		int a;
		for(a=0;a<nbStates;a++)
		{
			seqStates[oldidx][a].initFind();
			for (l=0;l<seqStates[oldidx][a].size();l++) //F=F U Fk
			{
				seq2=seqStates[oldidx][a].currentItem();
				F.add(seq2);
				seqStates[oldidx][a].findNext();
			}
			seqStates[oldidx][a].initFind();
			for (l=0;l<seqStates[oldidx][a].size();l++)
			{
				seq2=seqStates[oldidx][a].currentItem();
				for (int b=0;b<nbStates;b++) //transition a->b
				{
					if (automaton[a*nbStates+b]!=NULL) //there are some transition between a->b
					{
						seqStates[oldidx][b].initFind();
						for (l2=0;l2<seqStates[oldidx][b].size();l2++)
						{
							seq3=seqStates[oldidx][b].currentItem();
							generated=overlappedAdd(a,&seqStates[1-oldidx][a],seq2, seq3) || generated ;
							seqStates[oldidx][b].findNext();
						}
					}// if (automaton[a*nbStates+b]!=NULL)
				}//for (int b=0;b<nbStates;b++) 
				seqStates[oldidx][a].findNext();
			}//or (l=0;l<seqStates[oldidx][a].size();l++)
		}// for(a=0;a<nbStates;a++)
		delete[] seq.seq;
		for(a=0;a<nbStates;a++)
			seqStates[oldidx][a].clear();
	}// if (generation==1), else branch
	generation++;
	return generated;
}

void spiritL::pruneCandidates()
{

}

bool spiritL::test(sequence* seq, int state, int k)
{
	int i,l;
	if (k==seq->len)
		return (nbStates-1==state);
	for (i=0;i<nbStates;i++)
	{
			int* &transitions=automaton[state*nbStates+i]; //state->i
				if (transitions!=NULL)
				{
					l=1;
					while (l<=transitions[0] && seq->seq[k]!=transitions[l])
					{
						l++;
					}; // transitions
					if (l<=transitions[0])
						if (test(seq,i,k+1))
							return true;
				}
	}
	return false;
}



void spiritL::mineSolution(sequence* seq,ITelements* d,itemset* it)
{
	if (d==NULL)
		return;
	int i;
	int len=seq->len++;
	for (i=0;i<d->nbElements;i++)
	{
		seq->len=len+1;
		seq->seq[len]=d->list[i].symbol;
		if (d->list[i].count>-1) //
		{
			if (test(seq,0,0))
				it->add(seq);
		}
		mineSolution(seq,d->list[i].siblings,it);
	}
}

itemset* spiritL::getSolution()
{
	sequence s;
	s.len=0;
	s.seq=new int[sequence::maxtranlen];
	s.count=0;
	s.len=0;
	itemset* solution=new itemset;
	mineSolution(&s,&(F.data),solution);
	return solution;
}