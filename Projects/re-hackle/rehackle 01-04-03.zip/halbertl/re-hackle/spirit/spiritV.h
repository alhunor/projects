// spiritV.h: interface for the spiritV class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _SPIRITV_H__
#define _SPIRITV_H__

#include "../counter.h"

class stateList
{
public:
	stateList(int _nbStates):nbStates(_nbStates)
	{
		statesList[0]=new int[nbStates];
		statesList[1]=new int[nbStates];
		statesinList[0]=0;
		statesinList[1]=0;
	}
	virtual ~stateList();
	void clear(int list); // clears the statelist <list>;
	void addState(int list, int state); // adds teh sate <state> in the list <list>
	int* statesList[2];
	int statesinList[2];
protected:
	int nbStates;
};

class spiritV  
{
public:
	spiritV(int _nbStates, int** A, counter* C);
	virtual ~spiritV();
	bool generateCandidates();
	void pruneCandidates();
	itemset* getSolution() {return &solution;} // Should be called after the extraction in order 
protected:
	stateList* sList;
	itemset solution;
	itemset* seqStates[2];
	counter* candidates;
	int** automaton;
	int generation;
	int nbStates;
};

#endif 
