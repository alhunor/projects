// spirit.cpp : Defines the entry point for the console application.

#include <windows.h>
#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include <stdio.h>
#include "../alphabet.h"
#include "../counter.h"
#include "../transactions.h"
#include "spiritV.h"
#include "spiritL.h"
bool PRUNING=false; //exported constant, used by counter->add(..)

int **automaton;
int nbStates,nbTransitions;
extern alphabet alph; // from alphabet.cpp

#pragma warning (disable: 4244)

void loadAutomaton(char* name)
{
    int i,j,k,l,s;
	FILE* in = fopen(name, "r");     /* open input file for reading */
	fscanf(in,"%d %d", &nbStates,&nbTransitions);
	automaton=(int**)malloc(sizeof(int)*nbStates*nbStates);
	if (automaton==NULL)
	{
		cout<<"Out ofmemory."<<endl;
		exit(-1);
	};
	for (i=0;i<nbStates;i++)
		for (j=0;j<nbStates;j++)
		{
			automaton[i*nbStates+j]=NULL; //no transition from i->j
		}
	int nbItems;
	for (k=0;k<nbTransitions;k++)
	{
		fscanf(in,"%d %d %d",&i,&j,&nbItems);
		automaton[i*nbStates+j]=(int*)malloc(sizeof(int)*nbItems+1);
		automaton[i*nbStates+j][0]=nbItems;
		for (l=0;l<nbItems;l++)
		{
			fscanf(in,"%d",&s);
			automaton[i*nbStates+j][l+1]=alph.add(s);
		};
	}
	fclose(in);
}

int main(int argc, char* argv[])
{
	LARGE_INTEGER start,stop,freq;
	QueryPerformanceFrequency(&freq);
	int minsup=100; //absolute value
	cout<<"Loading the FSA into the Main Memory..."<<flush;
	loadAutomaton("sigkddA.aut");
	cout<<"done!"<<endl;
	transactions tb; // from transactions.cpp

	cout<<"Loading DB into the Main Memory..."<<flush;
//	tb.loadFromTextFile("../donnees/in.txt");	// loading transactions into the memory
	QueryPerformanceCounter(&start);
	tb.loadFromTextFile("f:\\halbertl\\out.txt");	// loading transaction into the memory
//	tb.loadFromTextFile("f:\\halbertl\\test.txt");	// loading transaction into the memory
	QueryPerformanceCounter(&stop);
	int ms2=1000*(stop.QuadPart-start.QuadPart)/freq.QuadPart;
	cout<<endl<<"Elapsed time "<<ms2<<" milliseconds"<<endl;
	
	cout<<"done!"<<endl;

	counter* candidates=new counter(&tb, minsup);
//	spiritL spirit(nbStates, automaton, candidates);

	spiritV spirit(nbStates, automaton, candidates);
	QueryPerformanceCounter(&start);
	int generation=1; 
	itemset its;
	bool generated=true;
	while (generated)
	{
		cout<<"----> Beginning generation "<<generation<<endl;
		generated=spirit.generateCandidates();
		if (generated)
		{
			cout<<candidates->size()<<" candidates to count"<<endl;
			spirit.pruneCandidates();
			candidates->count(true, &its);
			cout<<its.size()<<" were frequent!"<<endl;
			//cout<<its<<endl;
			if (its.size()==0)
			{
				generated=false; // stop the algorithm
			} else
				generation++;
		};
	};
	itemset* solution=spirit.getSolution();
	QueryPerformanceCounter(&stop);
	int ms=1000*(stop.QuadPart-start.QuadPart)/freq.QuadPart;
	cout<<"Solution:"<<endl;
	cout<<*solution<<endl;
	candidates->stat();
	cout<<"Elapsed time "<<ms<<" milliseconds"<<endl;
	cout<<generation<<" total gernerations."<<endl;
	return 0;
}