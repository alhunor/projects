// counter.h: interface for the counter class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _COUNTER_H__
#define _COUNTER_H__

#include "ExpressionTree.h"
#include "transactions.h"
#include "pruner.h"

struct element; // forward reference
class ExpressionTree; // forward reference

struct elements
{
	int nbElements;
	element* list;
	int dataSize;
};

struct element 
{
	int symbol; //simple symbol of the alphabet
#ifndef SPIRIT
	ExpressionTree **nodes; // Nodes in the tree containing the expression the symbol <symbol> is part of
	sequence** representation;
#else
	itemset** nodes; // Itemsets of the automaton ccollecting the frequent secences originating in
#endif
	int nbNodes; // number of such nodes
	int sizeofNodes; // espace reserve pour les noeuds
	int count; // if *nodes!=NULL, the support of the expression
	int epoch; // used by the counting phase
	elements* siblings; // next element of the expression
};

class counter  
{
public:
	counter(transactions* t, int msup);
	virtual ~counter();
public:
	bool empty();
	void clear();
	int size();
	void count(bool clear, itemset* i);
#ifndef SPIRIT
	void add(sequence* seq,sequence* level2Representation, ExpressionTree* T);
	void addItemset(itemset* i,ExpressionTree* T);
#else	
	void add(sequence* seq,itemset* origin/*, int end=0*/); 
	// adds the sequence <seq> to the list of the candidates 
	// where <origin> is Fk(state corresponding to origin) from which <seq> lasts 
	// until the terminating state of the FSA.
#endif
	void stat(); // for research purposes only
protected:
	element* lookup(elements* e, int symbol);
	element* insert(int* seq, elements* data,int len);
	void del(elements* d);
	void extract(itemset* it);
	void mine(sequence* s,elements* d, itemset* it);
	void count(int* transaction);
	int nbTotal;
	int nbItems;
	elements data;
	int minsup;
	Pruner pruner;
	transactions* tb;
	friend ostream& operator<<(ostream& os, counter& c);
	friend class KleeneTree;
private:
	int epoch;
	int opt1;
};

ostream& operator<<(ostream& os, counter& c);

#endif // _COUNTER_H__
