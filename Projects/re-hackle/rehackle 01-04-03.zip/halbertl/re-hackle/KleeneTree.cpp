// KleeneTree.cpp: implementation of the KleeneTree class.
//
//////////////////////////////////////////////////////////////////////

#include "alphabet2.h"
#include "counter.h"
#include "KleeneTree.h"
#include "itemset.h"
#include "transactions.h"
#include <memory.h>
#include <stdlib.h>

extern alphabet2 alph2; //alphabet2.cpp


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

KleeneTree::~KleeneTree()
{

}

KleeneTree::KleeneTree()
{
	type='*';
	age=0;
	state=Satisfied;
	klitemsSize=4;
	klitems=(ExpressionTree**)malloc(klitemsSize*sizeof(ExpressionTree*));
}

int KleeneTree::compute_ksith()
{
	if (explored)
		return ksiexp;
	if (age==0) 
	{
		return siblings->compute_ksith();	
	} else
	{
		return items->size()+klitems[age]->items->size()*klitems[age]->items->size();
	}
}

bool matching(int* s1, int *s2, int k)
{
	for (int i=1;i<k-1;i++)
	{
		if (s1[i]!=s2[i-1])
			return false;
	}
	return true;
}


void KleeneTree::apriori_gen(itemset* I, int k)
{
	int i,j;
	sequence s;
	sequence* seq;
	if (k==2)
	{
		s.seq=new int[2];
		s.len=2;
		s.count=0;
		for(i=0;i<I->size();i++)
			for(j=0;j<I->size();j++)
			{
				s.seq[0]=I->data[i].seq[0];
				s.seq[1]=I->data[j].seq[0];
				candidates->add(seq=alph2.toLevelOne(&s),&s,klitems[age+1]);
				delete[] seq->seq;
				delete seq;
			}
		delete[] s.seq;
	} else
	{
		s.seq=new int[k];
		s.len=k;
		s.count=0;
		int opa=0;
		for(i=0;i<I->size();i++)
			for(j=0;j<I->size();j++)
				if (matching(I->data[i].seq,I->data[j].seq,k))
				{
					memcpy(s.seq,I->data[i].seq,(k-1)*sizeof(int));
					s.seq[k-1]=I->data[j].seq[k-2];
					candidates->add(seq=alph2.toLevelOne(&s),&s,klitems[age+1]);
					opa++;
					delete[] seq->seq;
					delete seq;
				}
		delete[] s.seq;
		cout<<"opa="<<opa<<endl;
	}
}

void KleeneTree::generateCandidates(counter* candidates)
{
// Presumptions : siblings.items contains no duplicates
	if (explored)
		return;
	if (siblings->items->size()==0)
	{
		explored=true;
		return;
	};

	if (age+1>=klitemsSize)
	{
		ExpressionTree** buff=klitems;
		klitems=(ExpressionTree**)malloc(klitemsSize*2*sizeof(ExpressionTree*));
		if (klitems==NULL)
			exit(0);
		memcpy(klitems,buff,sizeof(ExpressionTree*)*klitemsSize);
		klitemsSize*=2;
		free(buff);
	};
	klitems[age+1]=new ExpressionTree;
	if (age==0)
	{
		//preparing to build the Alphabet();
		klitems[0]=new ExpressionTree;
		sequence s;
		s.seq=new int;
		s.len=1;
		// generating level 0 and the alphabet
		for (int i=0;i<siblings->items->size();i++)
		{
			if (siblings->items->data[i].len>1)
			{
				s.seq[0]=alph2.add(&siblings->items->data[i]);
			} else
				s.seq[0]=siblings->items->data[i].seq[0];
			klitems[age]->items->add(&s);
		};
		delete s.seq;
	};
	//age+2=k;

	cout<<age<<" klitems[age]->items->size():"<<klitems[age]->items->size()<<endl;
	if (klitems[age]->items->size()>0)
	{
		for (int i=0;i<klitems[age]->items->size();i++)
		{
			addLevelOne(&klitems[age]->items->data[i]);
		}
		apriori_gen(klitems[age]->items,age+2);
		//klitems[age]->items.clear();
		age++;
	} else
	{
		ksiexp=items->size();
		ksith=ksiexp;
		explored=true;
	};
}

ExpressionTree* KleeneTree::orphans(sequence* seq, bool th)
// liste les orphelins prefixes
{
	int* ksi=&ksiexp;
	if (th)
		ksi=&ksith;
	int len=seq->len;
	if (seq->len>0)
	{
		cout<<"KleeneTree::orphans->Error"<<endl;
	} else
	{
		siblings->orphans(seq,th);
	}; // if
	seq->len=len;
	return this;
}

void KleeneTree::addLevelOne(sequence* seq)
{
	sequence* s=alph2.toLevelOne(seq);
	items->add(s);
	delete[] s->seq;
	delete s;
}
