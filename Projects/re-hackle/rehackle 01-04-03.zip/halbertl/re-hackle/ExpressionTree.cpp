#include <stdlib.h>
#include <string.h>
#include "alphabet.h"
#include "alphabet2.h"
#include "bases.h"
#include "ExpressionTree.h"
#include "itemset.h"
#include "KleeneTree.h"
#include "sequence.h"

extern alphabet alph;
extern alphabet2 alph2;

ExpressionTree* rOrphans[MAXLEN];
int nbrOrphans=0;
counter* ExpressionTree::candidates;

static char op[MAXLEN];
static int oplen;
static ExpressionTreeP v[MAXLEN];
static int vlen;

ExpressionTree::ExpressionTree()
{
	parent=NULL;
	next=NULL;
	prev=NULL;
	siblings=NULL;
	ksith=1;
	ksiexp=-1; //not computed
	K=0;
	explored=false;
	state=unKnown;
	items=new itemset;
}

ExpressionTree::~ExpressionTree()
{
	delete items;
}

char ExpressionTree::fType()
{
	if (explored==false)
		return type;
	else
		return ' ';
}

bool ExpressionTree::nextKleene()
{
	ExpressionTree* tmp;
	bool b=false;
	switch (fType()) 
	{
		case '*':
			return true;
		case ' ':
			return false;
		case '.':
			return siblings->nextKleene();
		case '|':
			tmp=siblings;
			while (!b && tmp!=NULL)
			{
				b=b || tmp->nextKleene();
				tmp=tmp->next;
			};
			return b;
		default :
			return true; // this case shoul never occur		
	};
}


ExpressionTree* ExpressionTree::orphans(sequence* seq, bool th)
// liste les orphelins prefixes
{
	int* ksi=&ksiexp;
	if (th)
		ksi=&ksith;
	int len=seq->len;
	ExpressionTree* tmp;

	if (*ksi==1 && next==NULL && prev!=NULL && prev->type!='*' && parent!=NULL && parent->type=='.')
	// ??? prev->type!='*' should be generalized
	{
		rOrphans[nbrOrphans]=this;
		nbrOrphans++;
	};

	if (*ksi==1 && prev==NULL && next!=NULL && !next->nextKleene() && parent!=NULL && parent->type=='.')
	// NextKleene = next->type=='*' generalized
	{
		concatenate(seq,&items->data[0],0);
		parent->siblings=next;
		next->prev=NULL;
		next->orphans(seq,th);
	} else
	{
		if (seq->len>0)
		{
			switch(fType())
			{
				case '.':
					siblings->orphans(seq,th);
					seq->len=0;
					tmp=siblings->next;
					while (tmp!=NULL)
					{
						while (tmp!=NULL && tmp->prev==NULL)
							tmp=tmp->next;
						if (tmp!=NULL)
							tmp->orphans(seq,th);
						tmp=tmp->next;
					};
					break;
				case '|':
					tmp=siblings;
					while (tmp!=NULL)
					{
						tmp->orphans(seq,th);
						tmp=tmp->next;
					};
					break;
				case ' ':
					items->addPrefix(seq);
					break;
			};
		} else
		{
			tmp=siblings;
			while (tmp!=NULL)
			{
				tmp->orphans(seq,th);
				do 
				{
					tmp=tmp->next;		
				} while (tmp!=NULL && tmp->prev==NULL);

			};
		};
	};
	seq->len=len;
	if (type=='.' && siblings->next==NULL) //le noeud a un seul fils
	{
		if (parent!=NULL)
		{
			if (prev==NULL)
			{
				parent->siblings=siblings;
				//	delete this;
			} else
			{
				prev->next=siblings;
				siblings->prev=prev;
			};
			siblings->parent=parent;
			siblings->next=next;
			if (next!=NULL)
				next->prev=siblings;
			return this;
		} else
		{ 
			siblings->parent=NULL;
			return siblings;
		}
	};
	return this;
}

int ExpressionTree::compute_ksith()
{
	if (explored)
		return ksiexp;
	ExpressionTree* tmp=siblings;
	switch (fType())
	{
	case ' ':
		if (explored)
			ksith=ksiexp;
		return ksith;
	case '*': // gere par polymorphisme dans KleeneTree
		cout<<"Severe C++ error. Contact Bjarne Stroustroup at bs@research.att.com"<<endl;
		_exit(0);
		/*cout<<"ExpressionTree::compute_ksith"<<endl;
		return 1000; //a rafiner encore*/
	case '.':
		ksith=1;
		while (tmp!=NULL)
		{
			ksith*=tmp->compute_ksith();
			tmp=tmp->next;
		};
		return ksith;
	case '|':
		ksith=0;
		while (tmp!=NULL)
		{
			ksith+=tmp->compute_ksith();
			tmp=tmp->next;
		};
		return ksith;
	default:
		cout<<"ksi:Error."<<endl; // cause possible: Les intelliNodes ne sont pas encore implementes
		return -1;
	};
}

int ExpressionTree::priority(char c)
{
	switch (c)
	{
		case '.':
			return 2;
		case '|':
			return 1;
		case '*':
			return 3;
		default:
			cout<<"Unknown operator";
			return -1;
	};//switch
}


int ExpressionTree::pushV(char* c)
{
	int i=0;
	int j;
	sequence s;
	s.len=0;
	s.count=0;
	int* tmp=new int[32];
	char str[16];

	while (c[i]>='0' && c[i]<='9' || c[i]==' ')
	{
		j=0;
		while (c[i+j]>='0' && c[i+j]<='9')
		{
			j++;
		};
		if (j>0)
		{
			memcpy(str,c+i,j);
			str[j]=0;
			tmp[s.len]=alph.add(atoi(str));
			s.len++;
			i+=j-1;
		};
		i++;
	}
	s.seq=new int[s.len];
	memcpy(s.seq,tmp,sizeof(int)*s.len);

	if (vlen==MAXLEN)
	{
		cout<<"Too complicated expression."<<endl;
		return 0;
	};
	ExpressionTree* e=new ExpressionTree;
/*	e->expr=new char[i+1];
	memcpy(e->expr,c,i);
	e->expr[i]=0;
*/
	e->type=' ';
	e->items->add(&s);
	vlen++;
	v[vlen]=e;
	return i-1;
};

bool ExpressionTree::depiler()
{
	if (oplen==-1)
	{
		cout<<"Error."<<endl;
		return false;
	};
	char o=op[oplen];
	if (o=='(')
	{
		cout<<"Error: Invalid expression."<<endl;
		return false;
	};
	ExpressionTree* tmp=new ExpressionTree;
	ExpressionTree* tmp2;
	tmp->type=o;
	tmp->type=o;
	tmp2=v[vlen--];
	tmp2->parent=tmp;
	while (oplen>-1 && op[oplen]==o)
	{
		tmp2->prev=v[vlen--];
		tmp2->prev->next=tmp2;
		tmp2=tmp2->prev;
		tmp2->parent=tmp;
		oplen--;
	};
	tmp->siblings=tmp2;
	v[++vlen]=tmp;
	return true;
}

bool ExpressionTree::pushOP(char c)
{
	if (oplen>=0 && c!='(' && op[oplen]!='(' && priority(c)<priority(op[oplen]))
	{
		depiler();
	};
	if (oplen==MAXLEN)
	{
		cout<<"Too complicated expression."<<endl;
		return false;
	};
	oplen++;
	op[oplen]=c;
	return true;
}

void ExpressionTree::preorder(ExpressionTree* e, int k)
{
	for (int i=0;i<k;i++)
		cout<<" ";
	if (e->type==' ')
	{
		cout<<""<<*e->items<<" : "<<e<<endl;
	} else
		cout<<e->type<<" : "<<e<<endl;

	ExpressionTree* tmp=e->siblings;
	while(tmp!=NULL)
	{
		preorder(tmp,k+1);
		tmp=tmp->next;
	};
}

ExpressionTree* ExpressionTree::parse(char* req, counter* c)
//La chaine req ne doit pas contenir des espaces;
{
	oplen=-1;
	vlen=-1;
	candidates=c;
	ExpressionTree* tmp;
	int len=strlen(req);
	for (int i=0;i<len;i++)
	{
		switch(req[i])
		{
			case ' ':break;
			case '*':
				if (vlen<0)
				{
					cout<<"Error at position " << i<<endl;
					return NULL;
				};
				tmp=new KleeneTree();
				tmp->siblings=v[vlen];
				tmp->siblings->parent=tmp;
				v[vlen]=tmp;
				if (i<len-1 && req[i+1]=='*')
				{
					cout<<"Succesive * are not allowed."<<endl;
					return false;
				};
				if (i<len-1 && req[i+1]!='|' && req[i+1]!=')' && req[i+1]!='.' && req[i+1]!='(')
					pushOP('.');
				break;
			case '|':
			case '.':
				pushOP(req[i]);
				break;
			case '(':
				if (i>0 && req[i-1]!='.' && req[i-1]!='|' && req[i-1]!='(')
					pushOP('.');
				pushOP('(');
				break;
			case ')':
				while (oplen>-1 && op[oplen]!='(')
				{
					char o=op[oplen];
					ExpressionTree* tmp=new ExpressionTree;
					ExpressionTree* tmp2;
					tmp->type=o;
					tmp2=v[vlen--];
					tmp2->parent=tmp;
					while (oplen>-1 && op[oplen]==o)
					{
						tmp2->prev=v[vlen--];
						tmp2->prev->next=tmp2;
						tmp2=tmp2->prev;
						tmp2->parent=tmp;
						oplen--;
					};
					tmp->siblings=tmp2;
					v[++vlen]=tmp;
				};
				oplen--; //elever la paranthese ouverte
				if (i<len-1 && req[i+1]<='9' && req[i+1]>='0' )
					pushOP('.');
				break;
			case '0':;
			case '1':;
			case '2':;
			case '3':;
			case '4':;
			case '5':;
			case '6':;
			case '7':;
			case '8':;
			case '9':
				i=i+pushV(req+i);
				break;
			default:
				cout<<"Error at position " << i<<endl;
		};//switch(req[i])
	};
	while (oplen>-1)
	{
		char o=op[oplen];
		if (o=='(')
		{
			cout<<"Error: Invalid expression."<<endl;
			return NULL;
		};
		ExpressionTree* tmp=new ExpressionTree;
		ExpressionTree* tmp2;
		tmp->type=o;
		tmp2=v[vlen--];
		tmp2->parent=tmp;
		while (oplen>-1 && op[oplen]==o)
		{
			tmp2->prev=v[vlen--];
			tmp2->prev->next=tmp2;
			tmp2=tmp2->prev;
			tmp2->parent=tmp;
			oplen--;
		};
		tmp->siblings=tmp2;
		v[++vlen]=tmp;
	}
	return v[0];
}

ExpressionTree* ExpressionTree::simplify(bool th)
{
	sequence seq;
	seq.len=0;
	seq.seq=new int [MAXLEN];
	ExpressionTree* e=orphans(&seq,th);
/*
	seq.len=0;
	e.rOrphans(&seq,true);
*/
	delete[] seq.seq;
	return e;
}

void ExpressionTree::generateCandidates(counter* candidates)
{
	if (candidates==NULL)
	{
		cout<<"ExpressionTree::generateCandidates->Error"<<endl;
		return;
	};
	if (explored)
		return;
	if (state==Violated)
	{
		cout<<"ExpressionTree::generateCandidates->Error=state==Violated"<<endl;
		return;
	};
	ExpressionTree* tmp;
	int max[MAXLEN]; //MAx values of the counters
	ExpressionTree* sibtmp[MAXLEN];
	int counters[MAXLEN];
	int nbSiblings=0;
	int cpos;
	int i;
//	sequence* s;
	switch(type)
	{
		case ' ':
			candidates->add(&items->data[0],NULL,this);
			items->clear();
			break;
		case '.':
			tmp=siblings;
			sequence seq;
			seq.seq=new int[sequence::maxtranlen];
			while (tmp!=NULL)
			{
				if (tmp->type=='*')
					max[nbSiblings]=1;
				else
					max[nbSiblings]=0;
				if (tmp->items->size()>0)
				{
					max[nbSiblings]+=tmp->items->size(); //max values
					counters[nbSiblings]=0;
					sibtmp[nbSiblings]=tmp;
					sibtmp[nbSiblings]->items->initFind();
					nbSiblings++;
				};
				tmp=tmp->next;
			};
			cpos=nbSiblings-1;
			while (cpos>0)
			{
				seq.len=0;
				for(i=0;i<nbSiblings;i++)
				{
					if (!(counters[i]==0 && sibtmp[i]->type=='*'))
						if (seq.len==0)
							copy(&seq,sibtmp[i]->items->currentItem(),false);
						else
							if (!concatenate(&seq,sibtmp[i]->items->currentItem(),sibtmp[i]->K))
							{
								seq.len=0;
								break;
							}
				};
				seq.count=0;
				if (seq.len>0) // null sequences from *-nodes
				{
					candidates->add(alph2.toLevelOne(&seq),NULL,this);
/*					candidates->add(s=alph2.toLevelOne(&seq),&seq,this);
					delete[] s->seq;
					delete s;*/
				};
				if (counters[cpos]<max[cpos]-1)
				{
					if (!(counters[cpos]==0 && sibtmp[cpos]->type=='*'))
						sibtmp[cpos]->items->findNext();
					counters[cpos]++;
				} else
				{
					while (cpos>=0 && counters[cpos]==max[cpos]-1)
						cpos--;
					if (cpos>=0)
					{
						if (!(counters[cpos]==0 && sibtmp[cpos]->type=='*'))
							sibtmp[cpos]->items->findNext();
						counters[cpos]++;
						for (i=cpos+1;i<nbSiblings;i++)
						{
							counters[i]=0;
							sibtmp[i]->items->initFind();
						};
						cpos=nbSiblings-1;
					} //if
				} //if (counters[cpos]<max[cpos]-1)
			}; //while
			break;
		case '|':
			tmp=siblings;
			while (tmp!=NULL)
			{
				items->addItemset(tmp->items,true);
				tmp=tmp->next;
			};
			explored=true;
			ksiexp=items->size();
			if (ksiexp>0)
				state=Satisfied;
			else
			{
				state=Violated;
				propagateViolation();
			};
			break;
		case '*':
			//K->generateCandidates();
			break;
	};
}


bool ExpressionTree::violated()
{
	if (parent==NULL)
		return false;
	ExpressionTree* tmp=this;
	while (tmp!=NULL)
	{
		if (tmp->state==Violated)
			return true;
		tmp=tmp->parent;
	};
	return false;
}

bool ExpressionTree::ready()
{
	ExpressionTree* tmp=siblings;
	while (tmp!=NULL)
	{
		if (!tmp->explored)
			return false;
		tmp=tmp->next;
	};
	return true;
}

void ExpressionTree::propagateViolation()
//Invoked on a node whose violation needs to be propagated to his parents
{
	ExpressionTree* e=parent;
	while (e!=NULL && e->type!='|')
	{
		if (e->type=='.')
		{
			e->state=Violated;
			e->explored=true;
			e->ksiexp=0;
			ksiexp=0;
		};
		if (e->type=='*')
		{
		//	e->finishExploration();
			return;
		};
		e=e->parent;
	};//while
}

void ExpressionTree::goLevel2()
{
	itemset* ns=new itemset;
	sequence seq;
	seq.seq=new int;
	for (int i=0;i<items->size();i++)
	{
		if (items->data[i].len>1)
		{
			seq.len=1;
			*(seq.seq)=alph2.add(&items->data[i]);
			seq.count=0;
			ns->add(&seq);
		} else ns->add(&items->data[i]);
	};
	delete items;
	items=ns;
}


int ExpressionTree::countLeaves()
{
	if (type==' ')
	{
		return 1;
	} else
	{
		ExpressionTree* tmp=siblings;
		int nodes=0;
		while(tmp!=NULL)
		{
			nodes+=tmp->countLeaves();
			tmp=tmp->next;
		};
		return nodes;
	}
}


bool ExpressionTree::isparent(ExpressionTree* e)
{
	if (parent==e)
	{
		return true;
	} else 
	{
		if (parent==NULL)
		{
			return false;
		} else
		{
			return parent->isparent(e);
		}
	};
}
