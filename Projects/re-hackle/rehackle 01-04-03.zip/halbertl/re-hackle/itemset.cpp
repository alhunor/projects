// itemset.cpp: implementation of the itemset class.
//
//////////////////////////////////////////////////////////////////////

#include "itemset.h"
#include "sequence.h"
#include <memory.h>
#include <stdlib.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


itemset::~itemset()
{

}

itemset::itemset():nbItems(0),dataSize(STARTSIZE)
{
	data=new sequence[STARTSIZE];
}

bool itemset::empty()
{
	return nbItems==0;
}

int itemset::length()
// Cette fontion est definie seulement pour les iNodes
{
	if (nbItems==0)
		return 0;
	return data[0].len;
}


void itemset::addPrefix(sequence* seq)
{
	sequence s;
	if (nbItems==0)
	{
		add(seq);
		return;

	};
	for (int i=0; i<nbItems;i++)
	{
		s.len=seq->len+data[i].len;
		s.seq=new int[s.len];
		memcpy(s.seq,seq->seq,seq->len*sizeof(int));
		memcpy(s.seq+seq->len,data[i].seq,data[i].len*sizeof(int));
		delete[] data[i].seq;
		data[i].seq=s.seq;
		data[i].len=s.len;
	}
}


void itemset::clear()
{
	nbItems=0;
}

sequence* itemset::find(int pos)
{
	// there is no range checking
	return &data[pos];
}

sequence* itemset::currentItem()
{
	// there is no range checking
	return &data[findPos];
}

void itemset::initFind()
{
	findPos=0;
}


void itemset::findNext()
{
	findPos++;
}


void itemset::add(sequence* seq,bool checkpresence)
{
	if (checkpresence && in(seq))
		return;
	if (nbItems==dataSize)
	{
	// increase the buffer
		sequence* buff=data;
		dataSize*=2;
		data=new sequence[dataSize];
		if (data==NULL)
		{
			cout<<"Out of memory"<<endl;
			exit(-1);
		}
		memcpy(data,buff,sizeof(sequence)*nbItems);
		delete[] buff;
	};
	data[nbItems].count=seq->count;
	data[nbItems].len=seq->len;
	data[nbItems].seq=new int[seq->len];
	memcpy(data[nbItems].seq,seq->seq,sizeof(int)*seq->len);
	nbItems++;
}


bool itemset::in(sequence* seq)
{
	bool b;
	int i,j;
	for (i=0;i<nbItems;i++)
	{
		if (seq->len!=data[i].len)
			continue;
		b=true;
		for(j=0;j<seq->len;j++)
			if (data[i].seq[j]!=seq->seq[j])
			{
				b=false;
				break;
			};
		if (b)
			return true;
	};
	return false;
}


void itemset::addItemset(itemset* i, bool checkpresence)
{
	for(int j=0;j<i->nbItems;j++)
		add(&i->data[j],checkpresence);
}

ostream& operator<<(ostream& os, itemset& i)
{
	if (i.size()==0)
	{
		cout<<"Empty!";
		return os;
	};
	for (int j=0;j<i.size();j++)
	{
		cout<<'['<<i.data[j]<<']';
			if (j<i.size()-1)
				cout<<" ";
	};
	return os;
}

