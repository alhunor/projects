// ExtractionPhrase.h: interface for the ExtractionPhrase class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _EXTRACTIONPHRASE_H__
#define _EXTRACTIONPHRASE_H__

#include "ExpressionTree.h"
#include "counter.h"

static const ESTARTSIZE=16;

class ExpressionTree;

class ExtractionPhrase
{
public:
	ExtractionPhrase(counter* c);

	virtual ~ExtractionPhrase();
	ExtractionPhrase*  reBuild();
	void initPhrase(ExpressionTree* T);
	void addNode(ExpressionTree* N);
	bool empty() {return nbNodes==0;}
	counter* generateCandidates();
	void updateNodes();

protected:
	ExpressionTree **nodes;
	int nbNodes;
	int dataSize;
	counter* candidates;
private:
	bool addSimpleNode(ExpressionTree* N);
	int pos;
};

#endif // _EXTRACTIONPHRASE_H__
