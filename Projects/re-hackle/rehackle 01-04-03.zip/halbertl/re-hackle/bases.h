#ifndef _BASES_H__
#define _BASES_H__

bool contains(int *t,int* seq, int len);

#endif
