// transactions.h: interface for the transactions class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _TRANSACTIONS_H__
#define _TRANSACTIONS_H__

#include "bases.h"
#include "itemset.h"
//#include "counter.h"


class transactions
{
public:
	transactions() {for(int i=0;i<32768;i++) freq[i]=0;};
	void loadFromTextFile(char* name);
	void list();
	int getMaxtranlen() {return maxtranlen;}

	int freq[32768]; // frequency of the items (symbolic repr.)
	int nbTransactions;

private:
	int maxtranlen;
	int** tBase; //transaction Base
	friend class counter;
};

#endif
