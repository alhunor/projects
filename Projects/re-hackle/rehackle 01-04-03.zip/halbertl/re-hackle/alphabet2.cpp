// alphabet2.cpp: implementation of the alphabet2 class.
//
//////////////////////////////////////////////////////////////////////

#include "alphabet2.h"
#include "sequence.h"
#include <memory.h>
#include <stdlib.h>

alphabet2 alph2;


alphabet2::alphabet2()
{
	alphasize=0;
	maxalpha=8;
	alpha=new sequence[maxalpha];
};

alphabet2::~alphabet2()
{

}


int alphabet2::in(sequence* seq)
// return 0 if seq is not already in the alphabet,
// and its index if it is.
{
	int i,j;
	for (i=0;i<alphasize;i++)
	{
		if (seq->len!=alpha[i].len)
			continue;
		for (j=0;j<seq->len;j++)
		{
			if (seq->seq[j]!=alpha[i].seq[j])
				break;
		}
		if (j==seq->len)
			return i;
	}	
	return 0;
}

int alphabet2::add(sequence* seq)
{

	int pos=in(seq);
	if (pos==0) // not in
	{
		if (alphasize==maxalpha)
		{
			sequence* buff=alpha;
			maxalpha*=2;
			alpha=new sequence[maxalpha];
			if (alpha==NULL)
			{
				cout<<"alphabet2::add->Out of memory"<<endl;
				exit(-1);
			};
			memcpy(alpha,buff,sizeof(sequence)*alphasize);
			delete[] buff;
		};
		alpha[alphasize].len=0; // will be initialised by copy
		copy(&alpha[alphasize],seq);
		pos=alphasize++;
	};
	return -pos-1; // code -1 is stored at position 0!
}
	

sequence* alphabet2::toLevelOne(sequence* seq)
{
	sequence* s=new sequence;
	s->len=0;
	s->seq=new int[sequence::maxtranlen*2]; //??? put *3 if overflow
	int i;
	int c;
	for (i=0;i<seq->len;i++)
	{
		c=seq->seq[i];
		if (c>=0)
		{
			s->seq[s->len]=c;
			s->len++;
		} else
			concatenate(s,&alpha[-c-1],0);
	};
	return s;
}