// Pruner.cpp: implementation of the Pruner class.
//
//////////////////////////////////////////////////////////////////////

#include "Pruner.h"
//#include "ExpressionTree.h"
#include "itemtree.h"
#include <memory.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


int Pruner::getSupport(sequence* seq)
{
	nbItems++;
	int support=candbase.checkandinsert(seq);
	if (support!=-1) // already counted
		nbFilteredItems++;
	return support;
}

/*
Pruner::Pruner(ExpressionTree* e)
{
	expTree=e;
	nodes=expTree->countLeaves();
	nbExtractedNodes=0;
	extractedNodes= new ExpressionTreeP[nodes];
}

//void Pruner::addCandidat(ExpressionTree* n)


void Pruner::addNode(ExpressionTree* n)
// keep only those nodes <node> for that parent(n,node) is false
{
	ExpressionTreeP* oldNodes=new ExpressionTreeP[nbExtractedNodes];
	memcpy(oldNodes,extractedNodes,nbExtractedNodes*sizeof(ExpressionTreeP));
	int newnbNodes=0;
	for(int i=0;i<nbExtractedNodes;i++)
		if (!oldNodes[i]->isparent(n))
		{
			extractedNodes[newnbNodes]=oldNodes[i];
			newnbNodes++;
		}
	extractedNodes[newnbNodes]=n; //add th new node
	nbExtractedNodes=newnbNodes+1;
	delete[] oldNodes;
}

Pruner::~Pruner()
{
	delete[] extractedNodes;
	nbExtractedNodes=0;
}

*/



void Pruner::stat()
{
	cout<<"Pruner had filtered out "<<nbFilteredItems<<" candidates."<<endl;
}
