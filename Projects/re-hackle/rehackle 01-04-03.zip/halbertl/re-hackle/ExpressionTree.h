#ifndef _EXPRESSIONTREE_H__
#define _EXPRESSIONTREE_H__

#include "bases.h"
#include "itemset.h"
#include "counter.h"

typedef enum {Satisfied, Violated, unKnown} stateT;

const MAXLEN=1000; // Max operators in an expression

class ExpressionTree
{
	friend class ExtractionPhrase;
public:
	void goLevel2();
	ExpressionTree();
	virtual ~ExpressionTree();
	static ExpressionTree* parse(char* req, counter* c);
	void preorder(ExpressionTree* e, int k);
	virtual int compute_ksith();
	virtual void generateCandidates(counter* candidates);
	int ExpressionTree::countLeaves();
	
	ExpressionTree* simplify(bool th);
	bool violated(); // returns true if the node ore one of his parents are violated
	itemset* items;
	virtual ExpressionTree* orphans(sequence* s, bool th); // if th==true the computation 
	// is done with the theoretical cardinalities of the nodes instead of 
	// the experimental one. Used by the first call immediately before the 
	// constraction of the first extraction phrase after parse()
	bool isparent(ExpressionTree* e);
	// returns true, if e is a (possibly indirect) parent of the node

protected:

	char type;
	int ksiexp;
	int ksith;
	int K; // parametre K pour la concat�nationk-telescope
	stateT state;
	bool explored;
	ExpressionTree* parent;
	ExpressionTree *siblings; // pointeur sur le premier fils
	ExpressionTree *next; // voisins au meme niveau dans le sous-arbre associ� � son pere;
	ExpressionTree *prev; // voisins au meme niveau dans le sous-arbre associ� � son pere;
	//Les fils d'un pere sont stockes dans une liste doublement enchaine non circulaire,
	// r�alis�e � l'aide des champs nex et prev.
//	char *expr; //La sous-expression r�guli�re asoci� au noeud.
	static bool depiler();
	static bool pushOP(char c);
	static int pushV(char* c);
	static int priority(char c);
	bool ready(); // returns true, if all the leaves of the node have been explored
	void propagateViolation();
	static counter* candidates;
	char fType();

	friend class IntelliNode;
private:
	bool nextKleene();
};

typedef ExpressionTree* ExpressionTreeP;


#endif //#ifndef _EXPRESSIONTREE_H__
