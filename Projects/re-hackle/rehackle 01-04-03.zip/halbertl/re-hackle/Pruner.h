// Pruner.h: interface for the Pruner class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _PRUNER_H__
#define _PRUNER_H__

//#include "expressionTree.h"
#include "itemtree.h"

class Pruner  
{
public:
	void stat();
	
	Pruner() : nbFilteredItems(0),nbItems(0) {}
	virtual ~Pruner() {candbase.empty();}
	int getSupport(sequence* seq);
	void setSupport(sequence* seq, int frequency) {candbase.setfrequency(seq,frequency);}
	// return -1 if <seq> was not yet counted
	// or otherwise its frequecy
	// each call to check(seq) ads <seq> to the database
protected:
	itemtree candbase;
	int nbFilteredItems; // number of candidates filtered out
	int nbItems;
};

#endif // #ifndef _PRUNER_H__