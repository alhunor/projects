// alphabet.h: interface for the alphabet class.
//
//////////////////////////////////////////////////////////////////////
#ifndef _ALPHABET_H__
#define _ALPHABET_H__

class alphabet  
{
public:
	int alphabet::add(int i);
	int item(int code);
	int itemNr() {return iNr;}
	
	alphabet():iNr(0)
	{
		for (int i=0;i<32768;i++)
			alph[i]=-1;
	}
	virtual ~alphabet();

protected:
	int iNr; // how many distinct items
	int alph[32768]; //translation table
	int alphInv[32768]; //translation table for the inverse mapping
};

#endif