// KleeneTree.h: interface for the KleeneTree class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _KLEENETREE_H__
#define _KLEENETREE_H__

#include "ExpressionTree.h"
#include "itemset.h"

class KleeneTree : public ExpressionTree  
{
public:
	KleeneTree();
	virtual ~KleeneTree();
	void KleeneTree::generateCandidates(counter* candidates);
	virtual int compute_ksith();
	virtual ExpressionTree* orphans(sequence* seq, bool th);
	void addLevelOne(sequence* seq);
	int size(int age) {return klitems[age]->items->size();}
	int age;
protected:
	void apriori_gen(itemset* I, int k);
private:
	ExpressionTreeP* klitems; //Frequent items for each generation
	int klitemsSize;
};

#endif // _KLEENETREE_H__
