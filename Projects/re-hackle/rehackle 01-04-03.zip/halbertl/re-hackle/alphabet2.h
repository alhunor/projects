// alphabet2.h: interface for the alphabet2 class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _ALPHABET2_H__
#define _ALPHABET2_H__

#include "sequence.h"
//#include "sequence.h"

class alphabet2  
{
public:
	alphabet2();
	virtual ~alphabet2();
	int add(sequence* seq);
	int in(sequence* seq);
	sequence* toLevelOne(sequence* seq);
protected:
	sequence* alpha;
	int alphasize;
private:
	int maxalpha; // taille de l'espace reserve pour l'alphabet
};

#endif // _ALPHABET2_H__
