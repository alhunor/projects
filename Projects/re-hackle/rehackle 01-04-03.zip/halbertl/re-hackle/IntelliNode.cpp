// IntelliNode.cpp: implementation of the IntelliNode class.
//
//////////////////////////////////////////////////////////////////////

#include "alphabet2.h"
#include "counter.h"
#include "ExpressionTree.h"
#include "IntelliNode.h"
#include "itemset.h"
#include "transactions.h"

extern alphabet2 alph2; //alphabet2.cpp


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IntelliNode::~IntelliNode(){}

IntelliNode::IntelliNode()
{
	type='I';
	nbSiblings=0;
	state=unKnown;
}

int IntelliNode::compute_ksith()
{
	return ksiexp;
}

void IntelliNode::generateCandidates(counter* candidates)
{
	if (candidates==NULL)
	{
		cout<<"ExpressionTree::generateCandidates->Error"<<endl;
		return;
	};

	if (explored)
		return;

	if (state==Violated)
	{
		cout<<"ExpressionTree::generateCandidates->Error=state==Violated"<<endl;
		return;
	};

	ExpressionTree* tmp;
	int* max=new int [nbSiblings]; //MAx values of the counters
	ExpressionTree** sibtmp=new ExpressionTreeP[nbSiblings];
	int* counters=new int[nbSiblings];
	tmp=siblings;
	for (int i=0;i<nbSiblings;i++)
	{
		if (tmp->type=='*')
				max[i]=1;
			else
				max[i]=0;
		if (tmp->items->size()>0)
		{
			max[i]+=tmp->items->size(); //max values
			counters[i]=0;
			sibtmp[i]=tmp;
			sibtmp[i]->items->initFind();
		};
		tmp=tmp->next;
	}; // for (int i=0;i<nbSiblings;i++)
	int cpos=nbSiblings-1;
	sequence seq,*s;
	seq.seq=new int[sequence::maxtranlen];
	while (cpos>0)
	{
		seq.len=0;
		seq.count=0;
		for(i=0;i<nbSiblings;i++)
		{
			if (!(counters[i]==0 && sibtmp[i]->type=='*'))
				if (seq.len==0)
				{
					copy(&seq,sibtmp[i]->items->currentItem(),false);
				} else
					if (!concatenate(&seq,sibtmp[i]->items->currentItem(),sibtmp[i]->K))
					{
						seq.len=0;
						break;
					}
					//concatenate(&seq,sibtmp[i]->items.currentItem(),sibtmp[i]->K);
		};
		if (seq.len>0) // null sequences from *-nodes
		{
			candidates->add(s=alph2.toLevelOne(&seq),&seq,this);
			delete[] s->seq;
			delete s;
		}
		if (counters[cpos]<max[cpos]-1)
		{
			if (!(counters[cpos]==0 && sibtmp[cpos]->type=='*'))
				sibtmp[cpos]->items->findNext();
			counters[cpos]++;
		} else
		{
			while (cpos>=0 && counters[cpos]==max[cpos]-1)
				cpos--;
			if (cpos>=0)
			{
				if (!(counters[cpos]==0 && sibtmp[cpos]->type=='*'))
					sibtmp[cpos]->items->findNext();
				counters[cpos]++;
				for (i=cpos+1;i<nbSiblings;i++)
				{
					counters[i]=0;
					sibtmp[i]->items->initFind();
				};
				cpos=nbSiblings-1;
			} //if
		} //if (counters[cpos]<max[cpos]-1)
	}; //while
	delete[] max;
	delete[] sibtmp;
	delete[] counters;
}

ExpressionTree* IntelliNode::orphans(sequence* seq, bool th)
{
	return this;
}
