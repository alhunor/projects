#ifndef _ITEMTREE_H__
#define _ITEMTREE_H__

#include "sequence.h"
#include "itemset.h"

class ExpressionTree; // forward reference

struct ITelement; // forward reference

struct ITelements
{
	int nbElements;
	ITelement* list;
	int dataSize;
};
struct ITelement 
{
	int symbol; //simple symbol of the alphabet
	ITelements* siblings; // next element of the expression
	int count; // frequency of the candidate,
	//-1 if this is not a terminal symbol
};


class itemtree
{

public:
	itemtree();
	virtual ~itemtree();
public:
	void add(sequence* seq);
	void addItemset(itemset* i);
	void addItemtree(itemtree* i);
	int checkandinsert(sequence* seq);
	void clear();
	bool empty();
	void extract();
	bool in(sequence* seq);
	void setfrequency(sequence* seq, int frequency);
	// Attention: if the item exists and its frequency<>-1 the function has no effect.
	int size();
	ITelements data;

protected:
	void del(ITelements* d);
	ITelement* insert(int* seq, ITelements* data,int len,int frequency=-1);
	ITelement* lookup(ITelements* e, int symbol);
	void mine(sequence* s,ITelements* d, bool list);
	int nbItems; // number of the items in this itemtree
};

#endif // _ITEMTREE_H__
