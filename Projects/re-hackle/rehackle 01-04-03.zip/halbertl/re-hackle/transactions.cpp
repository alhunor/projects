// transactions.cpp: implementation of the transactions class.
//
//////////////////////////////////////////////////////////////////////

#include "alphabet.h"
#include "bases.h"
#include "itemset.h"
#include "transactions.h"
#include <stdio.h>
#include <stdlib.h>

extern alphabet alph; // from alphabet.cpp

void transactions::loadFromTextFile(char* name)
{
	int i,j;
    FILE* in = fopen(name, "r");     /* open input file for reading */
	fscanf(in,"%d", &nbTransactions);
	nbTransactions=5000; // only now
	int nbItems;
	maxtranlen=0;
	// int transactions[i]=nombre d'items sur la ligne "i"
	tBase=(int**)malloc(sizeof(int)*nbTransactions);
	for (i=0;i<nbTransactions;i++)
	{
		fscanf(in,"%d",&nbItems);
		if (nbItems>maxtranlen)
			maxtranlen=nbItems;
		tBase[i]=(int*)malloc(sizeof(int)*nbItems);
		tBase[i][0]=nbItems;
		for (j=1;j<=nbItems;j++)
		{
			fscanf(in,"%d",&tBase[i][j]);
			tBase[i][j]=alph.add(tBase[i][j]); //insert the new symbol in the alphabet and translation 
			//of the transaction to a sybolic representation
			freq[tBase[i][j]]++;
		}
	}
	fclose(in);
	sequence::maxtranlen=maxtranlen;
}


void transactions::list()
{
	int i,j;
	cout<<"Transactions:"<<endl;
	for (i=0;i<nbTransactions;i++)
	{
		for (j=1;j<=tBase[i][0];j++)
			cout<<tBase[i][j]<<" ";
		cout<<endl;
	};
	cout<<"Frequences:"<<endl;
	for (i=0;i<alph.itemNr();i++)
		cout<<alph.item(i)<<" - "<<freq[i]<<endl;
}

