// alphabet.cpp: implementation of the alphabet class.
//
//////////////////////////////////////////////////////////////////////

#include "alphabet.h"
#include <iostream.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

alphabet alph; //Global


alphabet::~alphabet()
{

}


int alphabet::item(int code)
{
	if (code>=0)
	{
		return alphInv[code];
	} else 
	{
		cout<<"Alphabet::Item->Error"<<endl;
		return -1;
	}
}

int alphabet::add(int i) 
// adds item <i> to the alphabet and returns its symbolic 
// representation
{
	if (alph[i]==-1) // first occurence of the item
	{
		alph[i]=iNr;
		alphInv[iNr]=i;
		iNr++;
	};
	return alph[i];
};