// sequence.h: interface for the sequence class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _SEQUENCE_H__
#define _SEQUENCE_H__

#include <iostream.h>

struct sequence  
{
	int* seq;
	int count;
	int len;
	static int maxtranlen;

};

typedef  sequence* sequenceP;
bool operator==(const sequence& s1,const sequence& s2);

bool concatenate(sequence* seq, sequence* seq2,int k);
// concatenation k-telescope. Seq2 is apended to the end of seq. K positions 
// must overlap


ostream& operator<<(ostream& os, sequence& seq);
sequence* copy(sequence* seq,sequence* seq2, bool verify=true);
// Si <verify> est true la fonction est autorisee a augmenter 
// la longueur de laseq si seq.len<seq2.len
// Si verify est faux, on considere que seq->seq pointe sur 
// suffisamment d'octets reserves.

#endif // _SEQUENCE_H__