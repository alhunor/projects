// sequence.cpp: implementation of the sequence class.
//
//////////////////////////////////////////////////////////////////////

#include <iostream.h>
#include <memory.h>
#include "sequence.h"
#include "alphabet.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

int sequence::maxtranlen; // static from sequence.h


extern alphabet alph;


bool operator==(const sequence& s1,const sequence& s2)
{
	if (s1.len!=s2.len)
		return false;
	for (int i=0;i<s1.len;i++)
		if (s1.seq[i]!=s2.seq[i])
			return false;
	return true;
}

ostream& operator<<(ostream& os, sequence& seq)
{
	for (int i=0;i<seq.len;i++)
	{
		cout<<alph.item(seq.seq[i]);
		if (i<seq.len-1)
			cout<<" ";
	};
	return os;
}

bool concatenate(sequence* seq, sequence* seq2,int k)
{
// seq and seq2 are level1 sequences
	if (k>seq->len|| k>seq2->len)
		return false; //this should never happen
	for (int i=0;i<k;i++)
		if (seq->seq[seq->len+i-k]!=seq2->seq[i])
			return false;
	for (i=k;i<seq2->len;i++)
	{
		seq->seq[seq->len+i-k]=seq2->seq[i];
	};
	seq->len+=seq2->len-k;
	return true;
}

sequence* copy(sequence* seq,sequence* seq2, bool verify)
{
// copies seq2 into seq. the field <count> is not
// dealt with
	if (verify)
	{
		if (seq->len<seq2->len)
		{
			if (seq->len>0)
				delete[] seq->seq;
			seq->seq=new int[seq2->len];
		};
	};
	seq->len=seq2->len;
	if (seq2->len>1)
		memcpy(seq->seq,seq2->seq,seq2->len*sizeof(int));
	else
		seq->seq[0]=seq2->seq[0];
	return seq;
}