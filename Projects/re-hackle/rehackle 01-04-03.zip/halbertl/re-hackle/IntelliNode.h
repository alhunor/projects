// IntelliNode.h: interface for the IntelliNode class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _INTELLINODE_H__
#define _INTELLINODE_H__

#include "ExpressionTree.h"
//#include "itemset.h"

class IntelliNode: public ExpressionTree  
{
public:
	IntelliNode();
	virtual ~IntelliNode();
	virtual void generateCandidates(counter* candidates);
	virtual int compute_ksith();
	virtual ExpressionTree* orphans(sequence* seq, bool th);
protected:
	int nbSiblings;
	friend class ExtractionPhrase;
};

#endif // _INTELLINODE_H__
