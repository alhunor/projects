#include "bases.h"

//extern transactions tb;

bool contains(int *t,int* seq, int len)
// t[0] is the length of the transaction
{
	int pos;
	for(int i=0; i<=*t-len;i++)
	{
		pos=0;
		while(pos+i<*t && seq[pos]==t[1+i+pos])
		{
			pos++;
			if (pos==len)
				return true;
		}
	};
	return false;
}
