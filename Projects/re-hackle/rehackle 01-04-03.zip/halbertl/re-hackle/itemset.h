// itemset.h: interface for the itemset class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _ITEMSET_H__
#define _ITEMSET_H__
#include "sequence.h"

static const STARTSIZE=32;

class itemset  
{
public:
	itemset();
	virtual ~itemset();
	bool empty();
	void clear();
	int size() const {return nbItems;}
	void add(sequence* seq, bool checkpresence=false);
	bool in(sequence* seq);
	void addItemset(itemset* i, bool checkpresence);
	sequence* find(int i);
	void addPrefix(sequence* seq);
	void initFind();
	sequence* currentItem();
	void findNext();
	int length();

	sequence* data;
	int dataSize;
#ifdef SPIRIT
	int end;
#endif
protected:
	int nbItems;
	int findPos;
friend class counter;
};

typedef itemset* itemsetP;
ostream& operator<<(ostream& os, itemset& i);

#endif
